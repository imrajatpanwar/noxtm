Place static image assets for the public site here.

Expected asset for Profile Settings social icon:
- LinkedIn_icon.webp  (official LinkedIn square icon)

Once added, it will be served at: /images/LinkedIn_icon.webp
